import React, { useState } from 'react';
import axios from 'axios';

const Chatbot = () => {
  const [messages, setMessages] = useState([]); // Store chat messages
  const [userInput, setUserInput] = useState(''); // User input message

  // Function to send user input to the backend
  const sendMessage = async () => {
    if (!userInput.trim()) return;

    // Add the user's message to the messages list
    setMessages([...messages, { sender: 'user', text: userInput }]);

    try {
      // Make a POST request to the backend
      const response = await fetch('http://127.0.0.1:5000/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: userInput }),
      });

      if (response.ok) {
        const data = await response.json();
        // Add the chatbot's response to the messages list
        setMessages((prev) => [...prev, { sender: 'bot', text: data.response }]);
      } else {
        console.error('Failed to fetch response from the chatbot.');
      }
    } catch (error) {
      console.error('Error:', error);
    }

    // Clear the input field
    setUserInput('');
  };

  return (
    <div className="chatbot-container">
      <div className="chat-window">
        {messages.map((msg, index) => (
          <div
            key={index}
            className={`message ${msg.sender === 'user' ? 'user-message' : 'bot-message'}`}
          >
            {msg.text}
          </div>
        ))}
      </div>
      <div className="input-container">
        <input
          type="text"
          placeholder="Type your message..."
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
        />
        <button onClick={sendMessage}>Send</button>
      </div>
    </div>
  );
};


export default Chatbot;
