import React from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for redirection
import './Landing.css'
import Chatbot from './Chatbot';

const Landing = () => {
  const navigate = useNavigate(); // Initialize useNavigate hook

  // Logout handler
  const handleLogout = () => {
    // Clear the token (or any authentication data stored in localStorage)
    localStorage.removeItem('token');

    // Redirect to the login page
    navigate('/');
  };

  return (
    <div className="landing-container">
      <div className="navbar">
        <div className="logo">LexAssist</div>
        <div className="nav-links">
          <a href="/">Home</a>
          <a href="/about">About Us</a>
          <a href="/contact">Contact</a>
        </div>
        <button className="logout-button" onClick={handleLogout}>Logout</button>
      </div>
      <div className="hero-section">
        <Chatbot />
      </div>
    </div>
  );
};

export default Landing;
